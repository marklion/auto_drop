echo CTEST_FULL_OUTPUT \(Avoid ctest truncation of output\)
echo ====================================================
echo Results of running \"cygcheck -c -d\":
cygcheck -c -d
