.ExternalData
=============

The VTK ``.ExternalData`` directory is an object store for the
CMake ExternalData module that VTK uses to manage test input
and baseline data.
